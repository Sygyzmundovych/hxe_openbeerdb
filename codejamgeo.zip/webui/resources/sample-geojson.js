var breweries2 = {
    "type": "FeatureCollection",
    "features": [
{"type": "Feature", "geometry": {"type": "Point", "coordinates": [-97.7697, 30.2234]} ,"properties": {"popupContent": "brewery with id=1"},"id": 1},
{"type": "Feature", "geometry": {"type": "Point", "coordinates": [-122.393, 37.7825]} ,"properties": {"popupContent": "brewery with id=2"},"id": 2},
{"type": "Feature", "geometry": {"type": "Point", "coordinates": [-121.933, 37.2886]} ,"properties": {"popupContent": "brewery with id=1067"},"id": 1067},
{"type": "Feature", "geometry": {"type": "Point", "coordinates": [-104.874, 39.5678]} ,"properties": {"popupContent": "brewery with id=1068"},"id": 1068}
    ]
};